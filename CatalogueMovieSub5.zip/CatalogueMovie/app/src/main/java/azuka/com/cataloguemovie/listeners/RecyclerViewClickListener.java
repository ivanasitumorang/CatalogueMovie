package azuka.com.cataloguemovie.listeners;

import azuka.com.cataloguemovie.models.Movie;

/**
 * Created by Ivana Situmorang on 1/18/2019.
 */
public interface RecyclerViewClickListener {
    void onItemClickListener(Movie movie);
}
