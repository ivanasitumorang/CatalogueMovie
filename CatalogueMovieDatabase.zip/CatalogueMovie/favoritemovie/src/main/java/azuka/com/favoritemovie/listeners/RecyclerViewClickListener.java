package azuka.com.favoritemovie.listeners;

import azuka.com.favoritemovie.models.Movie;

/**
 * Created by Ivana Situmorang on 1/31/2019.
 */
public interface RecyclerViewClickListener {
    void onItemClickListener(Movie movie);
}
